#include <iostream>
#include "header.h"

int main(void)
{
	BestComImpl::SimpleFunc();
	ProgComImpl::SimpleFunc();
}
