/*
#include <iostream>

using namespace std;

class Point
{
private:
	int xpos, ypos;

public:

	void Init(int x, int y)
	{
		xpos = x;
		ypos = y;
	}

	void ShowPointInfo() const
	{
		cout << "[" << xpos << "," << ypos << "]" << endl;

	}

};

class Circle
{
private:
	int r;
	Point center;

public:
	
	void Init(int x1, int y1, int r1)
	{
		r = r1;
		center.Init(x1,y1);
	}

	void ShowCircleInfo() const
	{
		cout << "������ : " << r << endl;
		center.ShowPointInfo();
	}

};

class Ring
{
private:
	Circle circle1;
	Circle circle2;

public:
	void Init(int x1, int x2, int x3, int y1, int y2, int y3)
	{
		circle1.Init(x1,x2,x3);
		circle2.Init(y1,y2,y3);
	}

	void ShowRingInfo() const
	{
		cout << "���ʿ�" << endl;
		circle1.ShowCircleInfo();
		cout << "�۱���" << endl;
		circle2.ShowCircleInfo();
	}

};


int main(void)
{
	Ring ring;
	ring.Init(1, 1, 4, 2, 2, 9);
	ring.ShowRingInfo();
	return 0;
}

*/