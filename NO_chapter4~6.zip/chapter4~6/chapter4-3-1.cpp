/*
#include <iostream>
#include <cstring>

using namespace std;

namespace COMP_POS
{
	enum { CLERK,SENIOR,ASSIST,MANAGER};

	void Showrank(int rank)
	{
		switch (rank)
		{
		case CLERK:
			cout << "���" << endl;
			break;
		case SENIOR:
			cout << "����" << endl;
			break;
		case ASSIST:
			cout << "�븮" << endl;
			break;
		case MANAGER:
			cout << "�Ŵ���" << endl;
			break;
		}
	}
}


class NameCard
{
private:
	char* name;
	char* company;
	char* phone;
	int rank;

public:

	NameCard(char* name1, char* company1, char* phone1, int rank1) : rank(rank1)
	{
		name = new char[strlen(name1)+1];
		company = new char[strlen(company1) + 1];
		phone = new char[strlen(phone1) + 1];
		strcpy(name,name1);
		strcpy(company, company1);
		strcpy(phone, phone1);
	}

	void ShowNameCardInfo()
	{
		cout << "�̸� : " << name << endl;
		cout << "ȸ�� : " << company << endl;
		cout << "��ȭ��ȣ : " << phone << endl;
		cout << "���� : "; 
		COMP_POS::Showrank(rank);
		cout << endl;

		cout << endl;

	}

	~NameCard()
	{
		delete []name;
		delete []company;
		delete []phone;
	}

};





int main(void)
{
	NameCard manClerk("Lee", "ABCEng", "010-1111-2222", COMP_POS::CLERK);
	NameCard manSENIOR("Hong", "OrangeEng", "010-3333-4444", COMP_POS::SENIOR);
	NameCard manAssist("Kim", "SoGoodComp", "010-5555-6666", COMP_POS::ASSIST);
	manClerk.ShowNameCardInfo();
	manSENIOR.ShowNameCardInfo();
	manAssist.ShowNameCardInfo();

	return 0;

}
*/