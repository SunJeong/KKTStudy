#include <iostream>
#include <cstring>
using namespace std;

namespace COMP_POS
{
	enum
	{
		CLERK=1, SENIOR=2, ASSIST=3, MANAGER=4
	};
}

class NameCard
{
private:
	char *name;
	char *comp;
	char *tel;
	int pos;
public:
	NameCard(const char *strname, const char *strcomp, const char *strtel, int n): pos(n)
	{
		int len=strlen(strname)+1;
		name=new char[len];
		strcpy(name,strname);
		
		len=strlen(strcomp)+1;
		comp=new char[len];
		strcpy(comp,strcomp);
		
		len=strlen(strtel)+1;
		tel=new char[len];
		strcpy(tel,strtel);
		cout<<"������ ȣ��"<<endl;
	}
	NameCard(const NameCard &copy): pos(copy.pos)
	{
		int len=strlen(copy.name)+1;
		name=new char[len];
		strcpy(name,copy.name);
		
		len=strlen(copy.comp)+1;
		comp=new char[len];
		strcpy(comp,copy.comp);
		
		len=strlen(copy.tel)+1;
		tel=new char[len];
		strcpy(tel,copy.tel);
		cout<<"��������� ȣ��"<<endl;
	}
	void ShowNameCardInfo()
	{
		cout<<"�̸�: "<<name<<endl;
		cout<<"ȸ��: "<<comp<<endl;
		cout<<"��ȭ��ȣ: "<<tel<<endl;
		if(pos==1){
			cout<<"����: ���"<<endl;
		}else if(pos==2){
			cout<<"����: ����"<<endl;
		}else if(pos==3){
			cout<<"����: �븮"<<endl;
		}else{
			cout<<"����: ����"<<endl;
		}
	}
	~NameCard()
	{
		cout<<"��ü �Ҹ�"<<endl; 
	}
};

int main(void)
{
	NameCard manClerk("Lee","ABCEng","010-1111-2222", COMP_POS::CLERK);
	NameCard copy1=manClerk;
	NameCard manSENIOR("Hong","OrangeEng","010-3333-4444", COMP_POS::SENIOR);
	NameCard copy2=manSENIOR;
	copy1.ShowNameCardInfo();
	copy2.ShowNameCardInfo();
	return 0;
}
