#include <iostream>
#include <cstring>
using namespace std;

namespace COMP_POS
{
	enum
	{
		CLERK=1, SENIOR=2, ASSIST=3, MANAGER=4
	};
}

class NameCard
{
private:
	char *name;
	char *comp;
	char *tel;
	int pos;
public:
	NameCard(const char *strname, const char *strcomp, const char *strtel, int n): pos(n)
	{
		int len=strlen(strname)+1;
		name=new char[len];
		strcpy(name,strname);
		
		len=strlen(strcomp)+1;
		comp=new char[len];
		strcpy(comp,strcomp);
		
		len=strlen(strtel)+1;
		tel=new char[len];
		strcpy(tel,strtel);
	}
	void ShowNameCardInfo()
	{
		cout<<"�̸�: "<<name<<endl;
		cout<<"ȸ��: "<<comp<<endl;
		cout<<"��ȭ��ȣ: "<<tel<<endl;
		if(pos==1){
			cout<<"����: ���"<<endl;
		}else if(pos==2){
			cout<<"����: ����"<<endl;
		}else if(pos==3){
			cout<<"����: �븮"<<endl;
		}else{
			cout<<"����: ����"<<endl;
		}
	}
};

int main(void)
{
	NameCard manClerk("Lee","ABCEng","010-1111-2222", COMP_POS::CLERK);
	NameCard manSENIOR("Hong","OrangeEng","010-3333-4444", COMP_POS::SENIOR);
	NameCard manAssist("Kim","SoGoodComp","010-5555-6666", COMP_POS::ASSIST);
	manClerk.ShowNameCardInfo();
	manSENIOR.ShowNameCardInfo();
	manAssist.ShowNameCardInfo();
	return 0;
}
