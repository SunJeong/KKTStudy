#include <iostream>
using namespace std;

class Point
{
private:
	int xpos, ypos;
public:
	Point(int x, int y): xpos(x), ypos(y)
	{
	}
	void ShowPointInfo() const
	{
		cout<<"["<<xpos<<", "<<ypos<<"]"<<endl;
	}
};

class Circle
{
private:
	Point point;
	int radius;
public:
	Circle(int x, int y, int r): point(x,y), radius(r)
	{
		//point.Init(x,y);
		//point(x,y);
		//radius=r;
	}
	void ShowCircleInfo() const
	{
		cout<<"radius: "<<radius<<endl;
		point.ShowPointInfo();
	}
};

class Ring
{
private:
	Circle InnerCircle;
	Circle OuterCircle;
public:
	Ring(int xpos1, int ypos1, int r1, int xpos2, int ypos2, int r2): InnerCircle(xpos1,ypos1,r1), OuterCircle(xpos2,ypos2,r2)
	{
		//InnerCircle.Init(xpos1,ypos1,r1);
		//OuterCircle.Init(xpos2,ypos2,r2);
	}
	void ShowRingInfo() const
	{
		cout<<"Inner Circle Info..."<<endl;
		InnerCircle.ShowCircleInfo();
		cout<<"Outter Circle Info..."<<endl;
		OuterCircle.ShowCircleInfo();
	}
};

int main(void)
{
	Ring ring(1,1,4,2,2,9);
	//ring.Init(1, 1, 4, 2, 2, 9);
	ring.ShowRingInfo();
	return 0;
}


/*
Inner Circle Info...
radius: 4
[1,1]
Outter Circle Info...
radius: 9
[2,2]
*/

